import bonzai.api.*;

public class CompetitorWeightComparator implements WeightComparator
{
	public CompetitorWeightComparator() {
		super();
	}
	
	@Override
	public double compare(Node arg0) {
		return 0;
	}
}