import bonzai.api.*;

public class DoNothingAI implements AI {

	@Override
	public void takeTurn(AIGameState state) {
		//Does nothing
	}

}
